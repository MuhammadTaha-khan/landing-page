// "use client";
// import React, { useState } from "react";
// import Image from "next/image";
// import logo from "../../public/logo.png";
// import Link from "next/link";

// const Navbar: React.FC = () => {
//   const [isMenuOpen, setIsMenuOpen] = useState(false);

//   const handleMenuToggle = () => {
//     setIsMenuOpen(!isMenuOpen);
//   };

//   const handleSmoothScroll = (
//     event: React.MouseEvent<HTMLAnchorElement, MouseEvent>,
//     sectionId: string
//   ) => {
//     event.preventDefault();
//     const section = document.getElementById(sectionId);
//     if (section) {
//       section.scrollIntoView({
//         behavior: "smooth",
//       });
//     }
//   };

//   return (
//     <nav className="bg-white dark:bg-gray-900 fixed w-full z-20 top-0 start-0 border-b border-gray-200 dark:border-gray-600">
//       <div className="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
//         <a href="#" className="flex items-center justify-center space-x-2">
//           <Image src={logo} alt="Logo" width={52} height={52} />
//           <p>For Fund</p>
//         </a>

//         <div className="flex md:order-2 space-x-3 md:space-x-0 rtl:space-x-reverse ">
//           <div className="flex bg-primary text-white px-5 py-2 rounded-3xl items-center space-x-2">
//             <Link href="/resume.pdf" download className="flex items-center space-x-2">
//               <span>Download now</span>
//             </Link>
//           </div>

//           <div className="lg:hidden">
//             <button
//               type="button"
//               className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg lg:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
//               onClick={handleMenuToggle}
//             >
//               <span className="sr-only">Open main menu</span>
//               <svg
//                 className="w-5 h-5"
//                 aria-hidden="true"
//                 xmlns="http://www.w3.org/2000/svg"
//                 fill="none"
//                 viewBox="0 0 17 14"
//               >
//                 <path
//                   stroke="currentColor"
//                   strokeLinecap="round"
//                   strokeLinejoin="round"
//                   strokeWidth="2"
//                   d="M1 1h15M1 7h15M1 13h15"
//                 />
//               </svg>
//             </button>
//           </div>
//         </div>

//         <div className={`items-center justify-between w-full lg:flex lg:w-auto md:order-2 ${isMenuOpen ? "block" : "hidden"}`} id="navbar-sticky">
//           <ul className="flex flex-col p-4 lg:p-0 mt-4 font-medium border border-gray-100 rounded-lg bg-blue lg:space-x-8 rtl:space-x-reverse lg:flex-row lg:mt-0 lg:border-0 lg:bg-white dark:bg-gray-800 lg:dark:bg-gray-900 dark:border-gray-700 md:bg-gray-700 md:px-4 md:py-2 md:rounded-3xl">
//             <li>
//               <a
//                 href="#home"
//                 onClick={(e) => handleSmoothScroll(e, "home")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 Home
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#about"
//                 onClick={(e) => handleSmoothScroll(e, "about")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 About
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#how-it-works"
//                 onClick={(e) => handleSmoothScroll(e, "how-it-works")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 How it works
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#challenges"
//                 onClick={(e) => handleSmoothScroll(e, "challenges")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 Challenges
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#fundraising"
//                 onClick={(e) => handleSmoothScroll(e, "fundraising")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 Fundraising
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#faq"
//                 onClick={(e) => handleSmoothScroll(e, "faq")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 FAQ
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#contact"
//                 onClick={(e) => handleSmoothScroll(e, "contact")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 Contact
//               </a>
//             </li>
//           </ul>
//         </div>
//       </div>
//     </nav>
//   );
// };

// export default Navbar;























// "use client";
// import React, { useState } from "react";
// import { CgMenuGridO } from "react-icons/cg";
// import Image from "next/image";
// import logo from "../../public/logo.png";
// import Link from "next/link";

// const Navbar: React.FC = () => {
//   const [isMenuOpen, setIsMenuOpen] = useState(false);

//   const handleMenuToggle = () => {
//     setIsMenuOpen(!isMenuOpen);
//   };

//   const handleSmoothScroll = (
//     event: React.MouseEvent<HTMLAnchorElement, MouseEvent>,
//     sectionId: string
//   ) => {
//     event.preventDefault();
//     const section = document.getElementById(sectionId);
//     if (section) {
//       section.scrollIntoView({
//         behavior: "smooth",
//       });
//     }
//   };

//   return (
//     <nav className="bg-white dark:bg-gray-900 fixed w-full z-20 top-0 start-0 border-b border-gray-200 dark:border-gray-600">
//       <div className="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
//         {/* Logo */}
//         <a href="#" className="flex items-center justify-center space-x-2">
//           <Image src={logo} alt="Logo" width={52} height={52} />
//           <p>For Fund</p>
//         </a>

//         {/* Download Button and Menu Toggle for Mobile */}


//         {/* Navigation Menu */}
//         <div className={`items-center justify-between w-full lg:flex lg:w-auto md:order-2 ${isMenuOpen ? "block" : "hidden"}`} id="navbar-sticky">
//           <ul className="flex flex-col p-4 lg:p-0 mt-4 font-medium border border-gray-100 rounded-lg lg:space-x-8 rtl:space-x-reverse lg:flex-row lg:mt-0 lg:border-0 lg:bg-white dark:bg-gray-800 lg:dark:bg-gray-200 dark:border-gray-200 md:bg-gray-00 md:px-4 md:py-2 md:rounded-2xl">
//             <li>
//               <a
//                 href="#home"
//                 onClick={(e) => handleSmoothScroll(e, "home")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 Home
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#about"
//                 onClick={(e) => handleSmoothScroll(e, "about")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 About
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#how-it-works"
//                 onClick={(e) => handleSmoothScroll(e, "how-it-works")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 How it works
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#challenges"
//                 onClick={(e) => handleSmoothScroll(e, "challenges")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 Challenges
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#fundraising"
//                 onClick={(e) => handleSmoothScroll(e, "fundraising")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 Fundraising
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#faq"
//                 onClick={(e) => handleSmoothScroll(e, "faq")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 FAQ
//               </a>
//             </li>
//             <li>
//               <a
//                 href="#contact"
//                 onClick={(e) => handleSmoothScroll(e, "contact")}
//                 className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
//               >
//                 Contact
//               </a>
//             </li>
//           </ul>
//         </div>
//         <div className="flex md:order-2 space-x-3 lg:space-x-0 rtl:space-x-reverse ">
//           <div className="flex bg-primary text-white px-5 py-2 rounded-3xl items-center space-x-2">
//             <Link href="/resume.pdf" download className="flex items-center space-x-2">
//               <span>Download now</span>
//             </Link>
//           </div>

//           {/* Mobile Menu Button */}
//           <div className="lg:hidden">
//             <button
//               type="button"
//               className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg lg:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
//               onClick={handleMenuToggle}
//             >
//               <span className="sr-only">Open main menu</span>
//               <CgMenuGridO className="text-2xl  font-bold text-black dark:text-white" />
//             </button>
//           </div>
//         </div>
//       </div>
//     </nav>
//   );
// };

// export default Navbar;








"use client"


import React, { useState } from "react";
import { CgMenuGridO } from "react-icons/cg";
import Image from "next/image";
import logo from "../../public/logo.png";
import Link from "next/link";

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleMenuToggle = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSmoothScroll = (
    event: React.MouseEvent<HTMLAnchorElement, MouseEvent>,
    sectionId: string
  ) => {
    event.preventDefault();
    const section = document.getElementById(sectionId);
    if (section) {
      section.scrollIntoView({
        behavior: "smooth",
      });
    }
  };

  return (
    <nav className="bg-white dark:bg-gray-900 fixed w-full z-20 top-0 left-0 border-b border-gray-200 dark:border-gray-600">
      <div className="max-w-screen-xl flex items-center justify-between mx-auto p-4">
        {/* Logo */}
        <a href="#" className="flex items-center space-x-2">
          <Image src={logo} alt="Logo" width={52} height={52} />
          <p>For Fund</p>
        </a>

        {/* Download Button and Mobile Menu Toggle */}
        <div className="flex items-center space-x-4">
          {/* Download Button */}
          <div className="bg-primary text-white px-5 py-2 rounded-3xl">
            <Link href="/resume.pdf" download className="flex items-center">
              <span>Download now</span>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <button
              type="button"
              className="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
              onClick={handleMenuToggle}
            >
              <span className="sr-only">Open main menu</span>
              <CgMenuGridO className="text-2xl font-bold text-black dark:text-white" />
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <div
        className={`${
          isMenuOpen ? "block" : "hidden"
        } lg:flex items-center justify-center w-full`}
      >
        <ul className="flex flex-col p-4 lg:p-0 mt-4 font-medium border border-gray-100 rounded-lg lg:space-x-8 rtl:space-x-reverse lg:flex-row lg:mt-0 lg:border-0 lg:bg-white dark:bg-gray-800 lg:dark:bg-gray-200 dark:border-gray-200">
          <li>
            <a
              href="#home"
              onClick={(e) => handleSmoothScroll(e, "home")}
              className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
            >
              Home
            </a>
          </li>
          <li>
            <a
              href="#about"
              onClick={(e) => handleSmoothScroll(e, "about")}
              className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
            >
              About
            </a>
          </li>
          <li>
            <a
              href="#how-it-works"
              onClick={(e) => handleSmoothScroll(e, "how-it-works")}
              className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
            >
              How it works
            </a>
          </li>
          <li>
            <a
              href="#challenges"
              onClick={(e) => handleSmoothScroll(e, "challenges")}
              className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
            >
              Challenges
            </a>
          </li>
          <li>
            <a
              href="#fundraising"
              onClick={(e) => handleSmoothScroll(e, "fundraising")}
              className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
            >
              Fundraising
            </a>
          </li>
          <li>
            <a
              href="#faq"
              onClick={(e) => handleSmoothScroll(e, "faq")}
              className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
            >
              FAQ
            </a>
          </li>
          <li>
            <a
              href="#contact"
              onClick={(e) => handleSmoothScroll(e, "contact")}
              className="block py-2 px-3 rounded text-black lg:bg-transparent lg:p-0 dark:text-white"
            >
              Contact
            </a>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
